
public class Register {
   byte value;
}
